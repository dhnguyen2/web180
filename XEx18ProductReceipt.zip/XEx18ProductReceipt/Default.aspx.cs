﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using XEx18ProductReceipt.Models;
namespace XEx18ProductReceipt
{
    public partial class Default : System.Web.UI.Page
    {
        HalloweenEntities1 db = new HalloweenEntities1();


        public IQueryable<Category> DdlCategory_GetData()
    {
            ddlCategory.DataBind();

            return from Category in db.Categories.Include("Product")
               orderby Category.LongName
               select Category;
    }
        public IQueryable<Product> GrdProducts_GetData(string DdlCategory)
        {
           
            if (DdlCategory == null)
                DdlCategory = (from Category in db.Categories
                               orderby Category.LongName
                               select Category).FirstOrDefault().CategoryID;

            return from Product in db.Products
                   where Product.CategoryID == DdlCategory
                   orderby Product.Name
                   select Product;
        }
        }
    }
